import { htmlToSlateNodes } from "./htmlConversion";

// INTERNAL HELPERS
const parseInlineHtml = (str: string): any[] => {
  if (!str) return [{ text: "" }];
  if (/<\/?[a-z][\s\S]*?>/i.test(str)) {
    return htmlToSlateNodes(str);
  }
  return [{ text: str }];
};

const htmlToParagraphChildren = (str: string): any[] => {
  if (!str) return [{ text: "" }];
  const nodes = parseInlineHtml(str);
  if (nodes.length === 1 && nodes[0].type === "paragraph") {
    return nodes[0].children ?? [{ text: "" }];
  }
  if (nodes.length === 1 && "text" in nodes[0]) return nodes;
  const flatten = (ns: any[]): any[] =>
    ns.flatMap((n: any) => ("text" in n ? [n] : flatten(n.children || [])));
  const flat = flatten(nodes);
  return flat.length > 0 ? flat : [{ text: "" }];
};

// GENERIC SLATE BUILDERS  (non-BRD)

export const createSlateTable = (data: any[]): any => {
  if (!data || data.length === 0)
    return { type: "paragraph", children: [{ text: "" }] };

  const headers = Object.keys(data[0]);

  return {
    type: "table" as const,
    className: "editor-custom-table",
    children: [
      {
        type: "table-row" as const,
        children: headers.map((header) => ({
          type: "table-cell-header" as const,
          children: [
            {
              type: "paragraph" as const,
              children: [{ text: header.replace(/_/g, " "), bold: true }],
            },
          ],
        })),
      },
      ...data.map((row) => ({
        type: "table-row" as const,
        children: headers.map((key) => {
          const val = row[key];
          if (Array.isArray(val)) {
            return {
              type: "table-cell" as const,
              children:
                val.length > 0
                  ? val.map((item: string) => ({
                      type: "paragraph" as const,
                      children: [{ text: String(item) }],
                    }))
                  : [{ type: "paragraph" as const, children: [{ text: "" }] }],
            };
          }
          return {
            type: "table-cell" as const,
            children: [
              {
                type: "paragraph" as const,
                children: [{ text: String(val || "") }],
              },
            ],
          };
        }),
      })),
    ],
  };
};

export const createSlateBulletedList = (items: string[]): any => ({
  type: "bulleted-list" as const,
  children: items.map((item) => ({
    type: "list-item" as const,
    children: [{ text: String(item) }],
  })),
});

export const createSlateNumberedList = (items: string[]): any => ({
  type: "numbered-list" as const,
  children: items.map((item) => ({
    type: "list-item" as const,
    children: [{ text: String(item) }],
  })),
});

// BRD-SPECIFIC BUILDERS
const createBrdSlateTable = (data: any[]): any => {
  if (!data || data.length === 0)
    return { type: "paragraph", children: [{ text: "" }] };

  const headers = Object.keys(data[0]);

  return {
    type: "table" as const,
    className: "editor-custom-table",
    children: [
      {
        type: "table-row" as const,
        children: headers.map((header) => ({
          type: "table-cell-header" as const,
          children: [
            {
              type: "paragraph" as const,
              children: [{ text: header.replace(/_/g, " "), bold: true }],
            },
          ],
        })),
      },
      ...data.map((row) => ({
        type: "table-row" as const,
        children: headers.map((key) => {
          const val = row[key];

          if (Array.isArray(val)) {
            return {
              type: "table-cell" as const,
              children:
                val.length > 0
                  ? val.map((item: string) => ({
                      type: "paragraph" as const,
                      children: htmlToParagraphChildren(String(item)),
                    }))
                  : [{ type: "paragraph" as const, children: [{ text: "" }] }],
            };
          }

          const parsed = parseInlineHtml(String(val || ""));
          const hasBlocks = parsed.some(
            (n: any) => n.type !== undefined && !("text" in n),
          );
          return {
            type: "table-cell" as const,
            children: hasBlocks
              ? parsed
              : [{ type: "paragraph" as const, children: parsed }],
          };
        }),
      })),
    ],
  };
};

const createBrdBulletedList = (items: string[]): any => ({
  type: "bulleted-list" as const,
  children: items.map((item) => ({
    type: "list-item" as const,
    children: htmlToParagraphChildren(String(item)),
  })),
});

// transformBRDDataToSlate

export const transformBRDDataToSlate = (obj: any): any[] => {
  if (!obj) return [{ type: "paragraph", children: [{ text: "" }] }];

  return Object.entries(obj).flatMap(([key, value]) => {
    if (
      key === "Executive_Summary" &&
      typeof value === "object" &&
      value !== null
    ) {
      const sectionHeader = {
        type: "heading-five" as const,
        children: [{ text: "Executive Summary" }],
      };

      const subNodes = Object.entries(value).flatMap(([subKey, subValue]) => {
        const subHeadingText = subKey.replace(/_/g, " ");
        const parsedHeading = parseInlineHtml(subHeadingText);

        const subHeadingNode = /<\/?[a-z]/i.test(subKey)
          ? parsedHeading
          : [
              {
                type: "heading-five" as const,
                children: [{ text: subHeadingText }],
              },
            ];

        const contentNodes = parseInlineHtml(String(subValue));
        const hasBlocks = contentNodes.some(
          (n: any) => n.type !== undefined && !("text" in n),
        );
        const contentBlock = hasBlocks
          ? contentNodes
          : [{ type: "paragraph" as const, children: contentNodes }];

        return [...subHeadingNode, ...contentBlock];
      });

      return [sectionHeader, ...subNodes];
    }

    if (key === "Stakeholders_and_Key_Personnel" && Array.isArray(value)) {
      return [
        {
          type: "heading-five" as const,
          children: [{ text: "Stakeholders & Key Personnel" }],
        },
        createBrdSlateTable(value),
      ];
    }

    if (key === "Goals_and_Objectives" && Array.isArray(value)) {
      return [
        {
          type: "heading-five" as const,
          children: [{ text: "Goals & objectives" }],
        },
        createBrdBulletedList(value),
      ];
    }

    if (
      key === "Process_Scope_Summary" &&
      typeof value === "object" &&
      value !== null
    ) {
      const sectionHeader = {
        type: "heading-five" as const,
        children: [{ text: "Process Scope Summary" }],
      };

      const scopeNodes = Object.entries(value).flatMap(
        ([scopeKey, scopeValue]: [string, any]) => {
          const scopeTitle = {
            type: "heading-five" as const,
            children: [{ text: scopeKey.replace(/_/g, " ") }],
          };

          const scopeContent = Object.entries(
            scopeValue as Record<string, any>,
          ).flatMap(([_subKey, subValue]: [string, any]) => {
            if (Array.isArray(subValue)) {
              return [createBrdBulletedList(subValue)];
            }
            const parsed = parseInlineHtml(String(subValue));
            const hasBlocks = parsed.some(
              (n: any) => n.type !== undefined && !("text" in n),
            );
            return hasBlocks
              ? parsed
              : [{ type: "paragraph" as const, children: parsed }];
          });

          return [scopeTitle, ...scopeContent];
        },
      );

      return [sectionHeader, ...scopeNodes];
    }

    if (key === "Glossary" && Array.isArray(value)) {
      return [
        { type: "heading-five" as const, children: [{ text: "Glossary" }] },
        createBrdSlateTable(value),
      ];
    }

    if (key === "Actors_Personas" && Array.isArray(value)) {
      return [
        {
          type: "heading-five" as const,
          children: [{ text: "Actors/Personas" }],
        },
        createBrdSlateTable(value),
      ];
    }

    return [
      {
        type: "heading-five" as const,
        className: `${key?.toLowerCase()}`,
        children: [{ text: key }],
      },
      {
        type: "paragraph" as const,
        className: `${key?.toLowerCase()}`,
        children: htmlToParagraphChildren(
          typeof value === "object" ? JSON.stringify(value) : String(value),
        ),
      },
    ];
  });
};
