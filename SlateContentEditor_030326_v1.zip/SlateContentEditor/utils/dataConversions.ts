import type { Descendant } from "slate";
import {
  cellToHtml,
  htmlToCellChildren,
  htmlToSlateNodes,
  slateToHtml,
} from "./htmlConversion";
import { transformBRDDataToSlate } from "./index";
import type { CustomText } from "../types";

// --- Helper: parse agent response (string → object) ---

export const parseAgentResponse = (raw: unknown): any => {
  if (typeof raw !== "string") return raw;
  let str = raw.trim();
  if (str.startsWith("```")) {
    str = str.replace(/^```(?:json)?\s*\n?/, "").replace(/\n?```\s*$/, "");
  }
  return JSON.parse(str);
};

// ============================================================
// TEST CASES
// ============================================================

const TC_VISIBLE_COLUMNS = [
  { key: "req_id", label: "Req ID" },
  { key: "userstory_id", label: "User Story ID" },
  { key: "TestCaseId", label: "Test Case ID" },
  { key: "TestCaseTitle", label: "Test Case Title" },
  { key: "Description", label: "Description" },
  { key: "Preconditions", label: "Preconditions" },
  { key: "TestData", label: "Test Data" },
  { key: "TestSteps", label: "Test Steps" },
  { key: "ExpectedResults", label: "Expected Results" },
];

export const testCasesToSlateValue = (data: any): Descendant[] => {
  const allRows: any[] = [];

  for (const req of data.Requirements || []) {
    for (const story of req.UserStories || []) {
      for (const act of story.AcceptanceCriteriaTests || []) {
        for (const tc of act.TestCases || []) {
          const hiddenData: Record<string, string> = {
            AcceptanceCriterion: act.AcceptanceCriterion || "",
            ActualResults: tc.ActualResults || "",
            PassFail: tc.PassFail || "",
          };

          const rowData: Record<string, any> = {
            req_id: req.req_id,
            userstory_id: story.userstory_id,
            TestCaseId: tc.TestCaseId,
            TestCaseTitle: tc.TestCaseTitle,
            Description: tc.Description,
            Preconditions: Array.isArray(tc.Preconditions)
              ? tc.Preconditions
              : [String(tc.Preconditions || "")],
            TestData: Array.isArray(tc.TestData)
              ? tc.TestData
              : [String(tc.TestData || "")],
            TestSteps: Array.isArray(tc.TestSteps)
              ? tc.TestSteps
              : [String(tc.TestSteps || "")],
            ExpectedResults: tc.ExpectedResults,
          };

          allRows.push({
            type: "table-row",
            hiddenData,
            children: TC_VISIBLE_COLUMNS.map(({ key }) => {
              const val = rowData[key];

              if (Array.isArray(val)) {
                return {
                  type: "table-cell",
                  children: val.flatMap((item: string) => {
                    return htmlToCellChildren(String(item || ""));
                  }),
                };
              }

              return {
                type: "table-cell",
                children: htmlToCellChildren(val != null ? String(val) : ""),
              };
            }),
          });
        }
      }
    }
  }

  const headerRow = {
    type: "table-row" as const,
    children: TC_VISIBLE_COLUMNS.map(({ label }) => ({
      type: "table-cell" as const,
      isHeader: true,
      children: [{ type: "paragraph" as const, children: [{ text: label }] }],
    })),
  };

  if (allRows.length === 0) {
    return [{ type: "paragraph", children: [{ text: "" }] }];
  }

  return [
    {
      type: "table",
      className: "editor-custom-table",
      children: [headerRow, ...allRows],
    },
  ];
};

export const slateToTestCasesJson = (nodes: Descendant[]): any => {
  const tableNode = (nodes as any[]).find((n) => n.type === "table");
  if (!tableNode) return { Requirements: [] };

  const dataRows = tableNode.children.slice(1);
  const reqMap: Record<string, any> = {};

  for (const row of dataRows) {
    const cells = row.children;
    const hidden = row.hiddenData || {};

    const reqId = cellToHtml(cells[0]).trim();
    const userstoryId = cellToHtml(cells[1]).trim();

    if (!reqMap[reqId]) {
      reqMap[reqId] = { req_id: reqId, UserStories: {} };
    }
    if (!reqMap[reqId].UserStories[userstoryId]) {
      reqMap[reqId].UserStories[userstoryId] = {
        userstory_id: userstoryId,
        AcceptanceCriteriaTests: {},
      };
    }

    const criterion = hidden.AcceptanceCriterion || "";
    const storyObj = reqMap[reqId].UserStories[userstoryId];
    if (!storyObj.AcceptanceCriteriaTests[criterion]) {
      storyObj.AcceptanceCriteriaTests[criterion] = {
        AcceptanceCriterion: criterion,
        TestCases: [],
      };
    }

    storyObj.AcceptanceCriteriaTests[criterion].TestCases.push({
      TestCaseId: cellToHtml(cells[2]).trim(),
      TestCaseTitle: cellToHtml(cells[3]).trim(),
      Description: cellToHtml(cells[4]).trim(),
      Preconditions: cellToHtml(cells[5])
        .split("\n")
        .map((s: string) => s.trim())
        .filter(Boolean),
      TestData: cellToHtml(cells[6])
        .split("\n")
        .map((s: string) => s.trim())
        .filter(Boolean),
      TestSteps: cellToHtml(cells[7])
        .split("\n")
        .map((s: string) => s.trim())
        .filter(Boolean),
      ExpectedResults: cellToHtml(cells[8]).trim(),
      ActualResults: hidden.ActualResults || "",
      PassFail: hidden.PassFail || "",
    });
  }

  // Convert maps back to arrays
  const requirements = Object.values(reqMap).map((req: any) => ({
    req_id: req.req_id,
    UserStories: Object.values(req.UserStories).map((story: any) => ({
      userstory_id: story.userstory_id,
      AcceptanceCriteriaTests: Object.values(story.AcceptanceCriteriaTests),
    })),
  }));

  return { Requirements: requirements };
};

// ============================================================
// ACTION LOG
// ============================================================

const AL_COLUMNS = [
  { key: "Action_Item", label: "Action Item" },
  { key: "Requestor", label: "Requestor" },
  { key: "Owner", label: "Owner" },
  { key: "Status", label: "Status" },
  { key: "Priority", label: "Priority" },
  { key: "Start_Date", label: "Start Date" },
  { key: "Due_Date", label: "Due Date" },
  { key: "Comments", label: "Comments" },
];

export const actionLogToSlateValue = (data: any): Descendant[] => {
  const items = data.Minutes_of_Meeting;
  if (!items || items.length === 0) {
    return [{ type: "paragraph", children: [{ text: "" }] }];
  }

  const allRows = items.map((item: any) => ({
    type: "table-row" as const,
    children: AL_COLUMNS.map(({ key }) => ({
      type: "table-cell" as const,
      children: htmlToCellChildren(item[key] != null ? String(item[key]) : ""),
    })),
  }));

  const headerRow = {
    type: "table-row" as const,
    children: AL_COLUMNS.map(({ label }) => ({
      type: "table-cell" as const,
      isHeader: true,
      children: [{ type: "paragraph" as const, children: [{ text: label }] }],
    })),
  };

  return [
    {
      type: "table",
      className: "editor-custom-table",
      children: [headerRow, ...allRows],
    },
  ];
};

export const slateToActionLogJson = (nodes: Descendant[]): any => {
  const tableNode = (nodes as any[]).find((n) => n.type === "table");
  if (!tableNode) return { Minutes_of_Meeting: [] };

  const dataRows = tableNode.children.slice(1);

  const minutes = dataRows.map((row: any) => {
    const result: Record<string, string> = {};
    AL_COLUMNS.forEach(({ key }, i) => {
      result[key] = cellToHtml(row.children[i]).trim();
    });
    return result;
  });

  return { Minutes_of_Meeting: minutes };
};

// ============================================================
// SUMMARY (markdown text → Slate)
// ============================================================

export const summaryToSlateValue = (text: string): Descendant[] => {
  if (!text || text.trim() === "") {
    return [{ type: "paragraph", children: [{ text: "" }] }];
  }

  // Handle previously saved HTML data (from old save code)
  let cleanText = text.trim();
  // Strip wrapping quotes if present (double-encoded responses)
  if (cleanText.startsWith('"') && cleanText.endsWith('"')) {
    try {
      cleanText = JSON.parse(cleanText);
    } catch {
      // not valid JSON, use as-is
    }
  }
  // Replace literal \n (escaped newlines) with actual newlines
  if (cleanText.includes("\\n")) {
    cleanText = cleanText.replace(/\\n/g, "\n");
  }
  // If the content is HTML, parse it using the HTML parser
  if (/^<[a-z][\s\S]*>/i.test(cleanText.trim())) {
    return htmlToSlateNodes(cleanText);
  }

  const lines = cleanText.split("\n");
  const nodes: Descendant[] = [];
  let currentListItems: Descendant[] = [];
  let currentListType: "bulleted-list" | null = null;

  const flushList = () => {
    if (currentListItems.length > 0 && currentListType) {
      nodes.push({
        type: currentListType,
        children: currentListItems as any,
      });
      currentListItems = [];
      currentListType = null;
    }
  };

  const parseInlineMarks = (text: string): CustomText[] => {
    const boldItalicRegex = /\*\*\*(.+?)\*\*\*/g;
    const boldRegex = /\*\*(.+?)\*\*/g;
    const italicRegex = /[\*_](.+?)[\*_]/g;
    const strikethroughRegex = /~~(.+?)~~/g;
    const underlineRegex = /<u>(.+?)<\/u>/gi;
    const codeRegex = /`(.+?)`/g;

    let parts: CustomText[] = [{ text }];

    const applyRegex = (regex: RegExp, prop: keyof CustomText) => {
      const newParts: CustomText[] = [];
      parts.forEach((part) => {
        if (Object.keys(part).length > 1) {
          newParts.push(part);
          return;
        }

        let lastIndex = 0;
        let match;
        const partText = part.text;
        regex.lastIndex = 0;

        while ((match = regex.exec(partText)) !== null) {
          if (match.index > lastIndex) {
            newParts.push({ text: partText.slice(lastIndex, match.index) });
          }
          newParts.push({ text: match[1], [prop]: true } as any);
          lastIndex = regex.lastIndex;
        }
        if (lastIndex < partText.length) {
          newParts.push({ text: partText.slice(lastIndex) });
        }
      });
      parts = newParts;
    };

    applyRegex(boldItalicRegex, "bold"); // Will need manual fix for nested marks
    applyRegex(boldRegex, "bold");
    applyRegex(italicRegex, "italic");
    applyRegex(strikethroughRegex, "strikethrough");
    applyRegex(underlineRegex, "underline");
    applyRegex(codeRegex, "code");

    return parts.length > 0 ? parts : [{ text: "" }];
  };

  for (const line of lines) {
    const trimmed = line.trim();

    if (trimmed === "") {
      flushList();
      continue;
    }

    // Numbered heading: "1. **Heading Text**"
    const numberedHeadingMatch = trimmed.match(/^\d+\.\s+\*\*(.+?)\*\*\s*$/);
    if (numberedHeadingMatch) {
      flushList();
      nodes.push({
        type: "heading-five",
        children: [{ text: numberedHeadingMatch[1] }],
      });
      continue;
    }

    // Sub-heading: short title-case phrase ending with colon (max 6 words)
    // Avoids matching full sentences like "Here's a structured summary...:"
    const subHeadingMatch = trimmed.match(/^([A-Z][^-*].+):$/);
    if (
      subHeadingMatch &&
      !trimmed.startsWith("-") &&
      !trimmed.startsWith("*") &&
      subHeadingMatch[1].split(/\s+/).length <= 6
    ) {
      flushList();
      nodes.push({
        type: "paragraph",
        children: [{ text: subHeadingMatch[1], bold: true }],
      });
      continue;
    }

    // Bullet item — use raw line to detect indentation level
    const bulletMatch = line.match(/^(\s*)([-*])\s+(.+)$/);
    if (bulletMatch) {
      const leadingSpaces = bulletMatch[1].length;
      const indent = leadingSpaces >= 4 ? 1 : 0;

      if (currentListType !== "bulleted-list") {
        flushList();
        currentListType = "bulleted-list";
      }
      currentListItems.push({
        type: "list-item",
        indent,
        children: parseInlineMarks(bulletMatch[3]),
      } as any);
      continue;
    }

    flushList();
    nodes.push({
      type: "paragraph",
      children: parseInlineMarks(trimmed),
    });
  }

  flushList();

  return nodes.length > 0
    ? nodes
    : [{ type: "paragraph", children: [{ text: "" }] }];
};

// ---- Helpers: Slate → Markdown ----

const leafToMarkdown = (node: any): string => {
  if (!node || !("text" in node)) return "";
  let text = node.text as string;
  if (!text) return "";
  if (node.code) text = `\`${text}\``;
  if (node.bold) text = `**${text}**`;
  if (node.italic) text = `*${text}*`;
  if (node.underline) text = `<u>${text}</u>`;
  if (node.strikethrough) text = `~~${text}~~`;
  return text;
};

const childrenToMarkdown = (children: any[]): string => {
  return (children || [])
    .map((c: any) => {
      if ("text" in c) return leafToMarkdown(c);
      return childrenToMarkdown(c.children);
    })
    .join("");
};

export const slateToSummaryJson = (nodes: Descendant[]): any => {
  // Save as HTML to preserve all formatting (font size, alignment, indent)
  // summaryToSlateValue detects HTML and roundtrips it through htmlToSlateNodes
  const html = slateToHtml(nodes);
  return { response: html };
};

const leafToInlineHtml = (node: any): string => {
  if (!node || !("text" in node)) return "";
  let html = node.text as string;
  if (!html) return "";
  if (node.code) html = `<code>${html}</code>`;
  if (node.italic) html = `<em>${html}</em>`;
  if (node.bold) html = `<strong>${html}</strong>`;
  if (node.underline) html = `<u>${html}</u>`;
  if (node.strikethrough) html = `<s>${html}</s>`;
  return html;
};

const childrenToInlineHtml = (children: any[]): string => {
  return (children || [])
    .map((c: any) => {
      if ("text" in c) return leafToInlineHtml(c);
      return childrenToInlineHtml(c.children);
    })
    .join("");
};

// ============================================================
// BRD (Slate → structured JSON)
// ============================================================

// Reverse display-name → JSON key mapping for top-level sections
const BRD_SECTION_DISPLAY_TO_KEY: Record<string, string> = {
  "Executive Summary": "Executive_Summary",
  "Stakeholders & Key Personnel": "Stakeholders_and_Key_Personnel",
  "Goals & objectives": "Goals_and_Objectives",
  "Goals & Objectives": "Goals_and_Objectives",
  "Process Scope Summary": "Process_Scope_Summary",
  "Actors/Personas": "Actors_Personas",
  Glossary: "Glossary",
};

const displayNameToKey = (name: string): string => {
  return BRD_SECTION_DISPLAY_TO_KEY[name] || name.replace(/ /g, "_");
};

const childrenToText = (children: any[]): string => {
  return (children || [])
    .map((c: any) => {
      if ("text" in c) return c.text || "";
      return childrenToText(c.children);
    })
    .join("");
};

const extractTableAsArray = (tableNode: any): any[] => {
  const rows = tableNode.children || [];
  if (rows.length < 2) return [];

  const headerCells = rows[0].children || [];
  const headers = headerCells.map((cell: any) => {
    const text = childrenToText(cell.children);
    return text.replace(/ /g, "_");
  });

  return rows.slice(1).map((row: any) => {
    const obj: Record<string, any> = {};
    (row.children || []).forEach((cell: any, i: number) => {
      if (i < headers.length) {
        const paragraphs = (cell.children || []).filter(
          (c: any) => c.type === "paragraph",
        );
        if (paragraphs.length > 1) {
          // Multiple paragraphs → was originally an array
          obj[headers[i]] = paragraphs.map((p: any) =>
            childrenToInlineHtml([p]),
          );
        } else {
          // Single paragraph → string
          obj[headers[i]] = childrenToInlineHtml(cell.children);
        }
      }
    });
    return obj;
  });
};

const extractBulletedListItems = (listNode: any): string[] => {
  return (listNode.children || []).map((item: any) =>
    childrenToInlineHtml(item.children),
  );
};

export const brdToSlateValue = (rawResponse: string): Descendant[] => {
  // Handle previously saved HTML data (from old save code)
  let cleanRaw =
    typeof rawResponse === "string" ? rawResponse.trim() : rawResponse;
  if (typeof cleanRaw === "string") {
    // Strip wrapping quotes if present
    if (cleanRaw.startsWith('"') && cleanRaw.endsWith('"')) {
      try {
        cleanRaw = JSON.parse(cleanRaw);
      } catch {
        // not valid JSON string, use as-is
      }
    }
    // Replace literal \n with actual newlines
    if (typeof cleanRaw === "string" && cleanRaw.includes("\\n")) {
      cleanRaw = cleanRaw.replace(/\\n/g, "\n");
    }
    // If the content is HTML, parse it using the HTML parser
    if (
      typeof cleanRaw === "string" &&
      /^<[a-z][\s\S]*>/i.test(cleanRaw.trim())
    ) {
      return htmlToSlateNodes(cleanRaw);
    }
  }
  const parsed = parseAgentResponse(cleanRaw);
  return transformBRDDataToSlate(parsed);
};

export const slateToBrdJson = (nodes: Descendant[]): any => {
  // Save as HTML to preserve all formatting (font size, alignment, indent, bullets)
  // brdToSlateValue detects HTML and roundtrips it through htmlToSlateNodes
  const html = slateToHtml(nodes);
  return { response: html };
};
