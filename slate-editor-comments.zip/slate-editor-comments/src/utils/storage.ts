import { Descendant } from 'slate';
import { Comment } from '../types/editor';

const CONTENT_KEY = 'slate_editor_content';
const COMMENTS_KEY = 'slate_editor_comments';

// ─── Default initial content ──────────────────────────────────────────────────

export const DEFAULT_CONTENT: Descendant[] = [
  {
    type: 'heading-one',
    children: [{ text: 'Welcome to Slate Editor ✦' }],
  },
  {
    type: 'paragraph',
    children: [
      { text: 'This is a fully featured rich text editor built with ' },
      { text: 'Slate.js', bold: true },
      { text: ' and ' },
      { text: 'React', bold: true, italic: true },
      { text: '. Select any text to start formatting or adding comments.' },
    ],
  },
  {
    type: 'heading-two',
    children: [{ text: 'Features' }],
  },
  {
    type: 'bulleted-list',
    children: [
      { type: 'list-item', children: [{ text: 'Rich text formatting: bold, italic, underline, strikethrough' }] },
      { type: 'list-item', children: [{ text: 'Font size and font family controls' }] },
      { type: 'list-item', children: [{ text: 'Text alignment: left, center, right, justify' }] },
      { type: 'list-item', children: [{ text: 'Indent and outdent support' }] },
      { type: 'list-item', children: [{ text: 'Comments with replies — saved to localStorage' }] },
    ],
  },
  {
    type: 'paragraph',
    children: [{ text: 'Try selecting this text and adding a comment using the toolbar above.' }],
  },
  {
    type: 'blockquote',
    children: [{ text: '"The best writing tools get out of the way and let you think."' }],
  },
  {
    type: 'paragraph',
    children: [{ text: '' }],
  },
];

// ─── Persistence ──────────────────────────────────────────────────────────────

export const saveContent = (content: Descendant[]): void => {
  try {
    localStorage.setItem(CONTENT_KEY, JSON.stringify(content));
  } catch (e) {
    console.warn('Failed to save editor content:', e);
  }
};

export const loadContent = (): Descendant[] | null => {
  try {
    const raw = localStorage.getItem(CONTENT_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as Descendant[];
  } catch {
    return null;
  }
};

export const saveComments = (comments: Comment[]): void => {
  try {
    localStorage.setItem(COMMENTS_KEY, JSON.stringify(comments));
  } catch (e) {
    console.warn('Failed to save comments:', e);
  }
};

export const loadComments = (): Comment[] => {
  try {
    const raw = localStorage.getItem(COMMENTS_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as Comment[];
  } catch {
    return [];
  }
};

export const clearStorage = (): void => {
  localStorage.removeItem(CONTENT_KEY);
  localStorage.removeItem(COMMENTS_KEY);
};
