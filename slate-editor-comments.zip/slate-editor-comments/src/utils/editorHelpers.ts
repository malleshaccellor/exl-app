import { Editor, Transforms, Text, Element as SlateElement, Range } from 'slate';
import { CustomText, CustomElement, TextAlign } from '../types/editor';

// ─── Mark Helpers ─────────────────────────────────────────────────────────────

export const isMarkActive = (editor: Editor, format: keyof CustomText): boolean => {
  const marks = Editor.marks(editor) as Record<string, unknown> | null;
  return marks ? marks[format as string] === true : false;
};

export const toggleMark = (editor: Editor, format: keyof CustomText): void => {
  const isActive = isMarkActive(editor, format);
  if (isActive) {
    Editor.removeMark(editor, format as string);
  } else {
    Editor.addMark(editor, format as string, true);
  }
};

export const setMark = <K extends keyof CustomText>(
  editor: Editor,
  format: K,
  value: CustomText[K]
): void => {
  Editor.addMark(editor, format as string, value);
};

export const getMarkValue = <K extends keyof CustomText>(
  editor: Editor,
  format: K
): CustomText[K] | undefined => {
  const marks = Editor.marks(editor) as Record<string, unknown> | null;
  return marks ? (marks[format as string] as CustomText[K]) : undefined;
};

// ─── Block Helpers ────────────────────────────────────────────────────────────

export const isBlockActive = (editor: Editor, format: string): boolean => {
  const { selection } = editor;
  if (!selection) return false;

  const [match] = Array.from(
    Editor.nodes(editor, {
      at: Editor.unhangRange(editor, selection),
      match: (n) => !Editor.isEditor(n) && SlateElement.isElement(n) && n.type === format,
    })
  );

  return !!match;
};

export const toggleBlock = (editor: Editor, format: string): void => {
  const isActive = isBlockActive(editor, format);
  const isList = ['bulleted-list', 'numbered-list'].includes(format);

  Transforms.unwrapNodes(editor, {
    match: (n) =>
      !Editor.isEditor(n) &&
      SlateElement.isElement(n) &&
      ['bulleted-list', 'numbered-list'].includes(n.type),
    split: true,
  });

  const newProperties: Partial<CustomElement> = {
    type: isActive ? 'paragraph' : isList ? 'list-item' : (format as CustomElement['type']),
  };

  Transforms.setNodes<CustomElement>(editor, newProperties);

  if (!isActive && isList) {
    const block = { type: format, children: [] } as unknown as CustomElement;
    Transforms.wrapNodes(editor, block);
  }
};

export const setBlockAlign = (editor: Editor, align: TextAlign): void => {
  Transforms.setNodes<CustomElement>(
    editor,
    { align } as Partial<CustomElement>,
    {
      match: (n) =>
        !Editor.isEditor(n) &&
        SlateElement.isElement(n) &&
        ['paragraph', 'heading-one', 'heading-two', 'heading-three'].includes(n.type),
    }
  );
};

export const getBlockAlign = (editor: Editor): TextAlign => {
  const { selection } = editor;
  if (!selection) return 'left';

  const [match] = Array.from(
    Editor.nodes(editor, {
      match: (n) =>
        !Editor.isEditor(n) &&
        SlateElement.isElement(n) &&
        ['paragraph', 'heading-one', 'heading-two', 'heading-three'].includes(n.type),
    })
  );

  if (match) {
    const el = match[0] as CustomElement & { align?: TextAlign };
    return el.align || 'left';
  }
  return 'left';
};

export const setBlockIndent = (editor: Editor, delta: number): void => {
  const { selection } = editor;
  if (!selection) return;

  const [match] = Array.from(
    Editor.nodes(editor, {
      match: (n) =>
        !Editor.isEditor(n) && SlateElement.isElement(n) && n.type === 'paragraph',
    })
  );

  if (match) {
    const el = match[0] as { indent?: number };
    const currentIndent = el.indent || 0;
    const newIndent = Math.max(0, Math.min(8, currentIndent + delta));
    Transforms.setNodes<CustomElement>(
      editor,
      { indent: newIndent } as Partial<CustomElement>,
      {
        match: (n) =>
          !Editor.isEditor(n) && SlateElement.isElement(n) && n.type === 'paragraph',
      }
    );
  }
};

// ─── Comment Helpers ──────────────────────────────────────────────────────────

export const addCommentMark = (editor: Editor, commentId: string): void => {
  if (editor.selection && !Range.isCollapsed(editor.selection)) {
    Editor.addMark(editor, 'commentId', commentId);
  }
};

export const removeCommentMark = (editor: Editor, commentId: string): void => {
  const nodes = Array.from(
    Editor.nodes(editor, {
      at: [],
      match: (n) => Text.isText(n) && (n as CustomText).commentId === commentId,
    })
  );

  for (const [, path] of nodes) {
    Transforms.unsetNodes(editor, 'commentId', { at: path });
  }
};
