import { SlateEditor } from './components/SlateEditor';
import './styles/editor.css';

function App() {
  return <SlateEditor />;
}

export default App;
