import type { BaseEditor, BaseRange, Descendant } from 'slate';
import type { ReactEditor } from 'slate-react';
import type { HistoryEditor } from 'slate-history';

export interface CommentReply {
  id: string;
  author: string;
  text: string;
  createdAt: string;
}

export interface Comment {
  id: string;
  author: string;
  text: string;
  createdAt: string;
  resolved: boolean;
  replies: CommentReply[];
  // Slate range for applying/removing marks in the editor
  range: BaseRange;
  // Selected text string — shown as quote chip in margin cards
  selectedText?: string;
}

export type TextAlign = 'left' | 'center' | 'right' | 'justify';

export type CustomText = {
  text: string;
  bold?: boolean;
  italic?: boolean;
  underline?: boolean;
  strikethrough?: boolean;
  fontSize?: number;
  fontFamily?: string;
  color?: string;
  highlight?: boolean;
  commentId?: string;
};

export type ParagraphElement = {
  type: 'paragraph';
  align?: TextAlign;
  indent?: number;
  children: CustomText[];
};

export type HeadingElement = {
  type: 'heading-one' | 'heading-two' | 'heading-three';
  align?: TextAlign;
  children: CustomText[];
};

export type BlockquoteElement = {
  type: 'blockquote';
  children: CustomText[];
};

export type CodeElement = {
  type: 'code';
  children: CustomText[];
};

export type ListItemElement = {
  type: 'list-item';
  children: CustomText[];
};

export type BulletedListElement = {
  type: 'bulleted-list';
  children: ListItemElement[];
};

export type NumberedListElement = {
  type: 'numbered-list';
  children: ListItemElement[];
};

export type DividerElement = {
  type: 'divider';
  children: CustomText[];
};

export type CustomElement =
  | ParagraphElement
  | HeadingElement
  | BlockquoteElement
  | CodeElement
  | ListItemElement
  | BulletedListElement
  | NumberedListElement
  | DividerElement;

declare module 'slate' {
  interface CustomTypes {
    Editor: BaseEditor & ReactEditor & HistoryEditor;
    Element: CustomElement;
    Text: CustomText;
  }
}

export type { Descendant };
