import React, { useState, useRef, useEffect } from 'react';
import {
  MessageSquare, X, ChevronDown, ChevronUp,
  CornerDownRight, CheckCheck, MessageSquarePlus, Check,
} from 'lucide-react';
import { Comment, CommentReply } from '../types/editor';

// ─── Single Comment Card ───────────────────────────────────────────────────────

interface CommentCardProps {
  comment: Comment;
  isActive: boolean;
  onClick: () => void;
  onResolve: (id: string) => void;
  onDelete:  (id: string) => void;
  onAddReply:(id: string, text: string) => void;
}

const CommentCard: React.FC<CommentCardProps> = ({
  comment, isActive, onClick, onResolve, onDelete, onAddReply,
}) => {
  const [showReply,   setShowReply]   = useState(false);
  const [replyText,   setReplyText]   = useState('');
  const [showReplies, setShowReplies] = useState(true);
  const replyRef = useRef<HTMLTextAreaElement>(null);
  useEffect(() => { if (showReply) replyRef.current?.focus(); }, [showReply]);

  const submitReply = () => {
    if (replyText.trim()) {
      onAddReply(comment.id, replyText.trim());
      setReplyText(''); setShowReply(false);
    }
  };

  const fmt = (iso: string) =>
    new Date(iso).toLocaleDateString('en-US', {
      month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit',
    });

  return (
    <div
      className={`comment-card ${isActive ? 'active' : ''} ${comment.resolved ? 'resolved' : ''}`}
      data-card-id={comment.id}
      onClick={onClick}
    >
      {/* Quote chip */}
      {comment.selectedText && (
        <div className="comment-card-quote">
          <span className="cq-bar" />
          <span className="cq-text">
            {comment.selectedText.length > 80
              ? comment.selectedText.slice(0, 80) + '…'
              : comment.selectedText}
          </span>
        </div>
      )}

      {/* Header */}
      <div className="comment-card-header">
        <div className="cc-avatar">{comment.author[0].toUpperCase()}</div>
        <div className="cc-meta">
          <span className="cc-author">{comment.author}</span>
          <span className="cc-date">{fmt(comment.createdAt)}</span>
        </div>
        <div className="cc-actions" onClick={e => e.stopPropagation()}>
          {!comment.resolved && (
            <button className="icon-btn" title="Resolve" onClick={() => onResolve(comment.id)}>
              <CheckCheck size={13} />
            </button>
          )}
          <button className="icon-btn danger" title="Delete" onClick={() => onDelete(comment.id)}>
            <X size={13} />
          </button>
        </div>
      </div>

      <p className="comment-card-body">{comment.text}</p>

      {comment.resolved && (
        <div className="resolved-badge"><CheckCheck size={11} /> Resolved</div>
      )}

      {/* Replies */}
      {comment.replies.length > 0 && (
        <div className="cc-replies">
          <button className="replies-toggle"
            onClick={e => { e.stopPropagation(); setShowReplies(p => !p); }}>
            {showReplies ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
            {comment.replies.length} {comment.replies.length === 1 ? 'reply' : 'replies'}
          </button>
          {showReplies && (
            <div className="replies-list">
              {comment.replies.map((r: CommentReply) => (
                <div key={r.id} className="reply-card">
                  <div className="reply-header">
                    <div className="reply-avatar">{r.author[0].toUpperCase()}</div>
                    <span className="reply-author">{r.author}</span>
                    <span className="cc-date">{fmt(r.createdAt)}</span>
                  </div>
                  <div className="reply-body">{r.text}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Reply input */}
      {!comment.resolved && (
        <div className="cc-reply-section" onClick={e => e.stopPropagation()}>
          {showReply ? (
            <div className="reply-form">
              <textarea ref={replyRef} className="reply-textarea"
                placeholder="Write a reply…" value={replyText}
                onChange={e => setReplyText(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) submitReply();
                  if (e.key === 'Escape') setShowReply(false);
                }} rows={2} />
              <div className="reply-actions">
                <button className="btn-sm-cancel"
                  onClick={() => { setShowReply(false); setReplyText(''); }}>Cancel</button>
                <button className="btn-sm-submit" onClick={submitReply}
                  disabled={!replyText.trim()}>Reply</button>
              </div>
            </div>
          ) : (
            <button className="reply-btn" onClick={() => setShowReply(true)}>
              <CornerDownRight size={12} /> Reply
            </button>
          )}
        </div>
      )}
    </div>
  );
};

// ─── New Comment Input (edit mode, shown in sidebar) ──────────────────────────

interface NewCommentInputProps {
  selectedText: string;
  onSubmit: (text: string) => void;
  onCancel: () => void;
}

const NewCommentInput: React.FC<NewCommentInputProps> = ({ selectedText, onSubmit, onCancel }) => {
  const [text, setText] = useState('');
  const ref = useRef<HTMLTextAreaElement>(null);
  useEffect(() => { ref.current?.focus(); }, []);
  const submit = () => { if (text.trim()) onSubmit(text.trim()); };

  return (
    <div className="new-comment-input-card">
      {selectedText && (
        <div className="comment-card-quote">
          <span className="cq-bar" />
          <span className="cq-text">
            {selectedText.length > 80 ? selectedText.slice(0, 80) + '…' : selectedText}
          </span>
        </div>
      )}
      <textarea ref={ref} className="new-comment-textarea"
        placeholder="Add a comment…" value={text}
        onChange={e => setText(e.target.value)}
        onKeyDown={e => {
          if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) submit();
          if (e.key === 'Escape') onCancel();
        }} rows={3} />
      <div className="new-comment-actions">
        <span className="new-comment-hint">Ctrl+↵</span>
        <button className="btn-sm-cancel" onClick={onCancel}>Cancel</button>
        <button className="btn-sm-submit" onClick={submit} disabled={!text.trim()}>
          <Check size={12} /> Comment
        </button>
      </div>
    </div>
  );
};

// ─── Comments Sidebar ──────────────────────────────────────────────────────────

interface CommentsSidebarProps {
  comments: Comment[];
  activeCommentId: string | null;
  onSelectComment: (id: string | null) => void;
  onResolve:  (id: string) => void;
  onDelete:   (id: string) => void;
  onAddReply: (id: string, text: string) => void;
  // Edit-mode new comment
  editPending?: { range: import('slate').Range; selectedText: string } | null;
  onSubmitEditPending?: (text: string) => void;
  onCancelEditPending?: () => void;
}

export const CommentsSidebar: React.FC<CommentsSidebarProps> = ({
  comments, activeCommentId, onSelectComment, onResolve, onDelete, onAddReply,
  editPending, onSubmitEditPending, onCancelEditPending,
}) => {
  const [showResolved, setShowResolved] = useState(false);

  const active   = comments.filter(c => !c.resolved);
  const resolved = comments.filter(c => c.resolved);
  const shown    = showResolved ? comments : active;

  return (
    <aside className="comments-sidebar">
      {/* Header */}
      <div className="sidebar-header">
        <div className="sidebar-title">
          <MessageSquare size={15} />
          <span>Comments</span>
          {active.length > 0 && (
            <span className="sidebar-badge">{active.length}</span>
          )}
        </div>
        {resolved.length > 0 && (
          <button className="sidebar-toggle-resolved"
            onClick={() => setShowResolved(p => !p)}>
            {showResolved ? 'Hide' : 'Show'} resolved ({resolved.length})
          </button>
        )}
      </div>

      {/* New comment input card — edit mode */}
      {editPending && onSubmitEditPending && onCancelEditPending && (
        <div className="sidebar-new-comment">
          <NewCommentInput
            selectedText={editPending.selectedText}
            onSubmit={onSubmitEditPending}
            onCancel={onCancelEditPending}
          />
        </div>
      )}

      {/* Comments list */}
      <div className="sidebar-list">
        {shown.length === 0 && !editPending ? (
          <div className="sidebar-empty">
            <MessageSquarePlus size={28} opacity={0.2} />
            <p>No comments yet</p>
            <p className="sidebar-empty-hint">Select text to add one</p>
          </div>
        ) : (
          shown.map(c => (
            <CommentCard
              key={c.id}
              comment={c}
              isActive={c.id === activeCommentId}
              onClick={() => onSelectComment(c.id === activeCommentId ? null : c.id)}
              onResolve={onResolve}
              onDelete={onDelete}
              onAddReply={onAddReply}
            />
          ))
        )}
      </div>
    </aside>
  );
};

// ─── Legacy export so any remaining import of MarginComments doesn't break ────
export const MarginComments = CommentsSidebar as unknown as React.FC<Record<string, unknown>>;
export const FloatingCommentBox: React.FC<Record<string, unknown>> = () => null;
