import React, { useCallback, useRef, useState } from 'react';
import { useSlate } from 'slate-react';
import {
  Bold, Italic, Underline, Strikethrough,
  AlignLeft, AlignCenter, AlignRight, AlignJustify,
  Indent, Outdent, List, ListOrdered,
  Heading1, Heading2, Heading3,
  Quote, Code,
  Undo, Redo, Highlighter,
  ChevronDown, MessageSquarePlus,
  RotateCcw, Save, Eye,
} from 'lucide-react';
import { HistoryEditor } from 'slate-history';
import {
  isMarkActive, toggleMark, setMark, getMarkValue,
  isBlockActive, toggleBlock, setBlockAlign, getBlockAlign, setBlockIndent,
} from '../utils/editorHelpers';
import { TextAlign } from '../types/editor';

const FONT_SIZES = [8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 28, 32, 36, 40, 48, 56, 64, 72];
const FONT_FAMILIES = [
  'Default', 'Georgia', 'Times New Roman', 'Courier New',
  'Arial', 'Verdana', 'Trebuchet MS', 'Impact',
];
const COLORS = [
  '#1a1a2e', '#e94560', '#0f3460', '#533483',
  '#e84393', '#00b4d8', '#06d6a0', '#ffd166',
  '#ef476f', '#118ab2', '#073b4c', '#ffffff',
];

interface ToolbarProps {
  onAddComment: () => void;
  onReset: () => void;
  onSave: () => void;
  hasUnsavedChanges: boolean;
}

// ─── ToolbarButton ────────────────────────────────────────────────────────────

interface ToolbarButtonProps {
  active?: boolean;
  disabled?: boolean;
  title: string;
  onClick: (e: React.MouseEvent) => void;
  children: React.ReactNode;
  className?: string;
}

const ToolbarButton: React.FC<ToolbarButtonProps> = ({
  active, disabled, title, onClick, children, className = '',
}) => (
  <button
    title={title}
    disabled={disabled}
    onMouseDown={(e) => { e.preventDefault(); onClick(e); }}
    className={`toolbar-btn ${active ? 'active' : ''} ${disabled ? 'disabled' : ''} ${className}`}
  >
    {children}
  </button>
);

const ToolbarDivider: React.FC = () => <span className="toolbar-divider" />;

// ─── Toolbar ──────────────────────────────────────────────────────────────────

export const Toolbar: React.FC<ToolbarProps> = ({ onAddComment, onReset, onSave, hasUnsavedChanges }) => {
  const editor = useSlate();
  const [fontSizeOpen, setFontSizeOpen] = useState(false);
  const [fontFamilyOpen, setFontFamilyOpen] = useState(false);
  const [colorOpen, setColorOpen] = useState(false);
  const fontSizeRef = useRef<HTMLDivElement>(null);
  const fontFamilyRef = useRef<HTMLDivElement>(null);
  const colorRef = useRef<HTMLDivElement>(null);

  const currentFontSize = getMarkValue(editor, 'fontSize') || 16;
  const currentFontFamily = getMarkValue(editor, 'fontFamily') || 'Default';
  const currentColor = getMarkValue(editor, 'color') || '#1a1a2e';
  const currentAlign = getBlockAlign(editor);

  const handleFontSize = useCallback((size: number) => {
    setMark(editor, 'fontSize', size);
    setFontSizeOpen(false);
  }, [editor]);

  const handleFontFamily = useCallback((family: string) => {
    if (family === 'Default') {
      setMark(editor, 'fontFamily', undefined as unknown as string);
    } else {
      setMark(editor, 'fontFamily', family);
    }
    setFontFamilyOpen(false);
  }, [editor]);

  const handleColor = useCallback((color: string) => {
    setMark(editor, 'color', color);
    setColorOpen(false);
  }, [editor]);

  const handleAlign = useCallback((align: TextAlign) => {
    setBlockAlign(editor, align);
  }, [editor]);

  return (
    <div className="toolbar">
      {/* History */}
      <ToolbarButton title="Undo (Ctrl+Z)" onClick={() => HistoryEditor.undo(editor)}>
        <Undo size={15} />
      </ToolbarButton>
      <ToolbarButton title="Redo (Ctrl+Y)" onClick={() => HistoryEditor.redo(editor)}>
        <Redo size={15} />
      </ToolbarButton>

      <ToolbarDivider />

      {/* Font Family */}
      <div className="toolbar-dropdown" ref={fontFamilyRef}>
        <button
          className="toolbar-select"
          onMouseDown={(e) => { e.preventDefault(); setFontFamilyOpen(p => !p); setFontSizeOpen(false); setColorOpen(false); }}
          title="Font Family"
        >
          <span style={{ fontFamily: currentFontFamily === 'Default' ? undefined : currentFontFamily }}>
            {currentFontFamily}
          </span>
          <ChevronDown size={12} />
        </button>
        {fontFamilyOpen && (
          <div className="toolbar-dropdown-menu font-family-menu">
            {FONT_FAMILIES.map(f => (
              <div
                key={f}
                className={`dropdown-item ${currentFontFamily === f ? 'selected' : ''}`}
                style={{ fontFamily: f === 'Default' ? undefined : f }}
                onMouseDown={(e) => { e.preventDefault(); handleFontFamily(f); }}
              >
                {f}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Font Size */}
      <div className="toolbar-dropdown" ref={fontSizeRef}>
        <button
          className="toolbar-select toolbar-select--narrow"
          onMouseDown={(e) => { e.preventDefault(); setFontSizeOpen(p => !p); setFontFamilyOpen(false); setColorOpen(false); }}
          title="Font Size"
        >
          <span>{currentFontSize}</span>
          <ChevronDown size={12} />
        </button>
        {fontSizeOpen && (
          <div className="toolbar-dropdown-menu font-size-menu">
            {FONT_SIZES.map(s => (
              <div
                key={s}
                className={`dropdown-item ${currentFontSize === s ? 'selected' : ''}`}
                onMouseDown={(e) => { e.preventDefault(); handleFontSize(s); }}
              >
                {s}
              </div>
            ))}
          </div>
        )}
      </div>

      <ToolbarDivider />

      {/* Headings */}
      <ToolbarButton title="Heading 1" active={isBlockActive(editor, 'heading-one')} onClick={() => toggleBlock(editor, 'heading-one')}>
        <Heading1 size={15} />
      </ToolbarButton>
      <ToolbarButton title="Heading 2" active={isBlockActive(editor, 'heading-two')} onClick={() => toggleBlock(editor, 'heading-two')}>
        <Heading2 size={15} />
      </ToolbarButton>
      <ToolbarButton title="Heading 3" active={isBlockActive(editor, 'heading-three')} onClick={() => toggleBlock(editor, 'heading-three')}>
        <Heading3 size={15} />
      </ToolbarButton>

      <ToolbarDivider />

      {/* Text Marks */}
      <ToolbarButton title="Bold (Ctrl+B)" active={isMarkActive(editor, 'bold')} onClick={() => toggleMark(editor, 'bold')}>
        <Bold size={15} />
      </ToolbarButton>
      <ToolbarButton title="Italic (Ctrl+I)" active={isMarkActive(editor, 'italic')} onClick={() => toggleMark(editor, 'italic')}>
        <Italic size={15} />
      </ToolbarButton>
      <ToolbarButton title="Underline (Ctrl+U)" active={isMarkActive(editor, 'underline')} onClick={() => toggleMark(editor, 'underline')}>
        <Underline size={15} />
      </ToolbarButton>
      <ToolbarButton title="Strikethrough" active={isMarkActive(editor, 'strikethrough')} onClick={() => toggleMark(editor, 'strikethrough')}>
        <Strikethrough size={15} />
      </ToolbarButton>
      <ToolbarButton title="Highlight" active={isMarkActive(editor, 'highlight')} onClick={() => toggleMark(editor, 'highlight')}>
        <Highlighter size={15} />
      </ToolbarButton>

      {/* Color Picker */}
      <div className="toolbar-dropdown" ref={colorRef}>
        <button
          className="toolbar-btn color-btn"
          onMouseDown={(e) => { e.preventDefault(); setColorOpen(p => !p); setFontSizeOpen(false); setFontFamilyOpen(false); }}
          title="Text Color"
        >
          <span style={{ color: currentColor, fontWeight: 'bold', fontSize: 14 }}>A</span>
          <span className="color-indicator" style={{ background: currentColor }} />
          <ChevronDown size={10} />
        </button>
        {colorOpen && (
          <div className="toolbar-dropdown-menu color-menu">
            <div className="color-grid">
              {COLORS.map(c => (
                <div
                  key={c}
                  className={`color-swatch ${currentColor === c ? 'selected' : ''}`}
                  style={{ background: c, border: c === '#ffffff' ? '1px solid #ccc' : undefined }}
                  onMouseDown={(e) => { e.preventDefault(); handleColor(c); }}
                  title={c}
                />
              ))}
            </div>
          </div>
        )}
      </div>

      <ToolbarDivider />

      {/* Alignment */}
      <ToolbarButton title="Align Left" active={currentAlign === 'left'} onClick={() => handleAlign('left')}>
        <AlignLeft size={15} />
      </ToolbarButton>
      <ToolbarButton title="Align Center" active={currentAlign === 'center'} onClick={() => handleAlign('center')}>
        <AlignCenter size={15} />
      </ToolbarButton>
      <ToolbarButton title="Align Right" active={currentAlign === 'right'} onClick={() => handleAlign('right')}>
        <AlignRight size={15} />
      </ToolbarButton>
      <ToolbarButton title="Justify" active={currentAlign === 'justify'} onClick={() => handleAlign('justify')}>
        <AlignJustify size={15} />
      </ToolbarButton>

      <ToolbarDivider />

      {/* Indent */}
      <ToolbarButton title="Outdent" onClick={() => setBlockIndent(editor, -1)}>
        <Outdent size={15} />
      </ToolbarButton>
      <ToolbarButton title="Indent" onClick={() => setBlockIndent(editor, 1)}>
        <Indent size={15} />
      </ToolbarButton>

      <ToolbarDivider />

      {/* Lists */}
      <ToolbarButton title="Bulleted List" active={isBlockActive(editor, 'bulleted-list')} onClick={() => toggleBlock(editor, 'bulleted-list')}>
        <List size={15} />
      </ToolbarButton>
      <ToolbarButton title="Numbered List" active={isBlockActive(editor, 'numbered-list')} onClick={() => toggleBlock(editor, 'numbered-list')}>
        <ListOrdered size={15} />
      </ToolbarButton>

      <ToolbarDivider />

      {/* Special blocks */}
      <ToolbarButton title="Blockquote" active={isBlockActive(editor, 'blockquote')} onClick={() => toggleBlock(editor, 'blockquote')}>
        <Quote size={15} />
      </ToolbarButton>
      <ToolbarButton title="Code Block" active={isBlockActive(editor, 'code')} onClick={() => toggleBlock(editor, 'code')}>
        <Code size={15} />
      </ToolbarButton>

      <ToolbarDivider />

      {/* Comment */}
      <ToolbarButton title="Add Comment" onClick={() => onAddComment()}>
        <MessageSquarePlus size={15} />
        <span className="toolbar-label">Comment</span>
      </ToolbarButton>

      {/* Spacer pushes save + reset to the right */}
      <div className="toolbar-spacer" />

      {/* Reset */}
      <ToolbarButton title="Reset Editor" onClick={() => onReset()}>
        <RotateCcw size={14} />
      </ToolbarButton>

      <ToolbarDivider />

      {/* Save & Preview */}
      <button
        className={`toolbar-save-btn ${hasUnsavedChanges ? 'unsaved' : 'saved'}`}
        onMouseDown={(e) => { e.preventDefault(); onSave(); }}
        title="Save & Preview (Ctrl+S)"
      >
        {hasUnsavedChanges ? (
          <>
            <Save size={14} />
            <span>Save & Preview</span>
            <span className="unsaved-dot" />
          </>
        ) : (
          <>
            <Eye size={14} />
            <span>Preview</span>
          </>
        )}
      </button>
    </div>
  );
};
