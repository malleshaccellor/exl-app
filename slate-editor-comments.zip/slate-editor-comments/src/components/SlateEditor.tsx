import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { createEditor, Descendant, Editor, Range, Transforms } from "slate";
import { Slate, Editable, withReact, ReactEditor } from "slate-react";
import { withHistory } from "slate-history";
import { v4 as uuid } from "uuid";
import { MessageSquare, MessageSquareOff, Eye, Edit3 } from "lucide-react";

import { Toolbar } from "./Toolbar";
import { Element, Leaf } from "./EditorElements";
import { CommentsSidebar } from "./Comments";
import { Comment } from "../types/editor";
import {
  addCommentMark,
  removeCommentMark,
  toggleMark,
} from "../utils/editorHelpers";
import {
  DEFAULT_CONTENT,
  saveContent,
  loadContent,
  saveComments,
  loadComments,
  clearStorage,
} from "../utils/storage";

// ─── Helpers ──────────────────────────────────────────────────────────────────

export function scrollToHighlight(
  commentId: string,
  container: HTMLElement | null,
) {
  if (!container) return;
  const spans = container.querySelectorAll<HTMLElement>(
    `[data-comment-id="${commentId}"]`,
  );
  if (!spans.length) return;
  spans[0].scrollIntoView({ behavior: "smooth", block: "center" });
  spans.forEach((el) => {
    el.classList.add("comment-flash");
    setTimeout(() => el.classList.remove("comment-flash"), 1400);
  });
}

function flashSidebarCard(commentId: string) {
  const card = document.querySelector<HTMLElement>(
    `[data-card-id="${commentId}"]`,
  );
  if (!card) return;
  card.scrollIntoView({ behavior: "smooth", block: "nearest" });
  card.classList.add("comment-card-flash");
  setTimeout(() => card.classList.remove("comment-card-flash"), 1400);
}

// ─── Inline Comment Box ────────────────────────────────────────────────────────

interface InlineBoxState {
  top: number;
  left: number;
  selectedText: string;
  slateRange: Range;
}

const InlineCommentBox: React.FC<{
  state: InlineBoxState;
  onSubmit: (text: string, range: Range, selectedText: string) => void;
  onCancel: () => void;
}> = ({ state, onSubmit, onCancel }) => {
  const [text, setText] = useState("");
  const ref = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const t = setTimeout(() => ref.current?.focus(), 30);
    return () => clearTimeout(t);
  }, []);

  const submit = () => {
    if (text.trim())
      onSubmit(text.trim(), state.slateRange, state.selectedText);
  };

  return (
    <div
      className="inline-comment-box"
      style={{ top: state.top, left: state.left }}
      onMouseDown={(e) => e.stopPropagation()}
      onClick={(e) => e.stopPropagation()}
    >
      <div className="icb-quote">
        <span className="icb-quote-bar" />
        <span className="icb-quote-text">
          {state.selectedText.length > 100
            ? state.selectedText.slice(0, 100) + "…"
            : state.selectedText}
        </span>
      </div>
      <textarea
        ref={ref}
        className="icb-textarea"
        placeholder="Add your comment…"
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
            e.preventDefault();
            submit();
          }
          if (e.key === "Escape") onCancel();
        }}
        rows={3}
      />
      <div className="icb-footer">
        <span className="icb-hint">Ctrl+Enter to post</span>
        <button className="icb-btn-cancel" onClick={onCancel}>
          Cancel
        </button>
        <button
          className="icb-btn-post"
          onClick={submit}
          disabled={!text.trim()}
        >
          Post comment
        </button>
      </div>
    </div>
  );
};

// ─── Main Component ────────────────────────────────────────────────────────────

export const SlateEditor: React.FC = () => {
  const editor = useMemo(() => withHistory(withReact(createEditor())), []);

  const [value, setValue] = useState<Descendant[]>(
    () => loadContent() || DEFAULT_CONTENT,
  );
  const [comments, setComments] = useState<Comment[]>(() => loadComments());
  const [activeId, setActiveId] = useState<string | null>(null);
  const [isPreview, setIsPreview] = useState(true);
  const [showComments, setShowComments] = useState(false); // preview: comments panel + highlights
  const [hasUnsaved, setHasUnsaved] = useState(false);
  const [savedAt, setSavedAt] = useState(
    () => localStorage.getItem("slate_editor_saved_at") || "",
  );
  const [previewBox, setPreviewBox] = useState<InlineBoxState | null>(null);
  const [editPending, setEditPending] = useState<{
    range: Range;
    selectedText: string;
  } | null>(null);

  const scrollRef = useRef<HTMLDivElement>(null);
  const pageRef = useRef<HTMLDivElement>(null);

  // ── Persist ────────────────────────────────────────────────────────────
  useEffect(() => {
    saveComments(comments);
  }, [comments]);

  const handleChange = useCallback((v: Descendant[]) => {
    setValue(v);
    setHasUnsaved(true);
  }, []);

  // ── Save ───────────────────────────────────────────────────────────────
  const handleSave = useCallback(() => {
    saveContent(value);
    saveComments(comments);
    const now = new Date().toISOString();
    setSavedAt(now);
    localStorage.setItem("slate_editor_saved_at", now);
    setHasUnsaved(false);
    setIsPreview(true);
    setPreviewBox(null);
    setEditPending(null);
  }, [value, comments]);

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "s") {
        e.preventDefault();
        handleSave();
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [handleSave]);

  // ── Keyboard shortcuts ─────────────────────────────────────────────────
  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case "b":
            e.preventDefault();
            toggleMark(editor, "bold");
            break;
          case "i":
            e.preventDefault();
            toggleMark(editor, "italic");
            break;
          case "u":
            e.preventDefault();
            toggleMark(editor, "underline");
            break;
        }
      }
    },
    [editor],
  );

  // ── Apply mark + create comment ────────────────────────────────────────
  const applyComment = useCallback(
    (text: string, range: Range, selectedText: string) => {
      const commentId = uuid();
      try {
        Transforms.select(editor, range);
        addCommentMark(editor, commentId);
      } catch (e) {
        console.warn("Could not apply comment mark:", e);
      }
      const newComment: Comment = {
        id: commentId,
        author: "You",
        text,
        createdAt: new Date().toISOString(),
        resolved: false,
        replies: [],
        range,
        selectedText,
      };
      setComments((prev) => [...prev, newComment]);
      setActiveId(commentId);
      setHasUnsaved(true);
      setTimeout(() => flashSidebarCard(commentId), 150);
      return commentId;
    },
    [editor],
  );

  // ── Edit mode: Comment button ──────────────────────────────────────────
  const handleEditAddComment = useCallback(() => {
    const { selection } = editor;
    if (!selection || Range.isCollapsed(selection)) {
      alert("Select some text first to add a comment.");
      return;
    }
    const domSel = window.getSelection();
    if (!domSel || domSel.rangeCount === 0) return;
    setEditPending({
      range: { ...selection },
      selectedText: domSel.toString().trim(),
    });
  }, [editor]);

  const handleEditCommentSubmit = useCallback(
    (text: string) => {
      if (!editPending) return;
      applyComment(text, editPending.range, editPending.selectedText);
      setEditPending(null);
    },
    [editPending, applyComment],
  );

  // ── Preview: mouseUp → show inline box (only when comments shown) ──────
  const handlePreviewMouseUp = useCallback(
    (e: React.MouseEvent) => {
      if (!showComments) return; // plain view — no comment box
      if ((e.target as HTMLElement).closest(".inline-comment-box")) return;

      const sel = window.getSelection();
      if (!sel || sel.isCollapsed || !sel.toString().trim()) return;

      const selectedText = sel.toString().trim();

      let slateRange: Range | null = null;
      try {
        slateRange = ReactEditor.toSlateRange(editor, sel, {
          exactMatch: false,
          suppressThrow: true,
        });
      } catch {
        /* ignore */
      }

      if (!slateRange || Range.isCollapsed(slateRange)) return;

      const domRange = sel.getRangeAt(0);
      const pageEl = pageRef.current;
      if (!pageEl) return;
      const pageRect = pageEl.getBoundingClientRect();

      const rects = Array.from(domRange.getClientRects());
      const lastRect =
        rects.length > 0
          ? rects[rects.length - 1]
          : domRange.getBoundingClientRect();

      const BOX_WIDTH = 320;
      const boxTop = lastRect.bottom - pageRect.top + 10;
      const rawLeft = lastRect.right - pageRect.left - BOX_WIDTH + 16;
      const boxLeft = Math.max(
        8,
        Math.min(rawLeft, pageRect.width - BOX_WIDTH - 8),
      );

      setPreviewBox({ top: boxTop, left: boxLeft, selectedText, slateRange });
    },
    [editor, showComments],
  );

  const handlePreviewCommentSubmit = useCallback(
    (text: string, range: Range, selectedText: string) => {
      applyComment(text, range, selectedText);
      setPreviewBox(null);
      window.getSelection()?.removeAllRanges();
    },
    [applyComment],
  );

  const handleCancelPreview = useCallback(() => {
    setPreviewBox(null);
    window.getSelection()?.removeAllRanges();
  }, []);

  // ── Page clicks ────────────────────────────────────────────────────────
  const handlePreviewPageClick = useCallback(
    (e: React.MouseEvent) => {
      const t = e.target as HTMLElement;
      if (!t.closest(".inline-comment-box")) setPreviewBox(null);

      if (showComments) {
        const span = t.closest("[data-comment-id]") as HTMLElement | null;
        if (span) {
          const id = span.dataset.commentId!;
          setActiveId((prev) => {
            const next = prev === id ? null : id;
            if (next) setTimeout(() => flashSidebarCard(next), 50);
            return next;
          });
        }
      }
    },
    [showComments],
  );

  const handleEditPageClick = useCallback((e: React.MouseEvent) => {
    const span = (e.target as HTMLElement).closest(
      "[data-comment-id]",
    ) as HTMLElement | null;
    if (span) {
      const id = span.dataset.commentId!;
      setActiveId((prev) => {
        const next = prev === id ? null : id;
        if (next) setTimeout(() => flashSidebarCard(next), 50);
        return next;
      });
    }
  }, []);

  // ── Card click → scroll to highlight ──────────────────────────────────
  const handleSelectComment = useCallback((id: string | null) => {
    setActiveId(id);
    if (id) setTimeout(() => scrollToHighlight(id, scrollRef.current), 50);
  }, []);

  // ── Toggle comments panel (preview only) ──────────────────────────────
  const handleToggleComments = useCallback(() => {
    setShowComments((prev) => {
      const next = !prev;
      if (!next) {
        // Closing — clear any open inline box and active selection
        setPreviewBox(null);
        setActiveId(null);
        window.getSelection()?.removeAllRanges();
      }
      return next;
    });
  }, []);

  // ── Resolve / Delete / Reply ───────────────────────────────────────────
  const handleResolve = useCallback(
    (id: string) => {
      setComments((prev) =>
        prev.map((c) => (c.id === id ? { ...c, resolved: true } : c)),
      );
      removeCommentMark(editor, id);
      if (activeId === id) setActiveId(null);
      setHasUnsaved(true);
    },
    [editor, activeId],
  );

  const handleDelete = useCallback(
    (id: string) => {
      setComments((prev) => prev.filter((c) => c.id !== id));
      removeCommentMark(editor, id);
      if (activeId === id) setActiveId(null);
      setHasUnsaved(true);
    },
    [editor, activeId],
  );

  const handleAddReply = useCallback((commentId: string, text: string) => {
    setComments((prev) =>
      prev.map((c) =>
        c.id === commentId
          ? {
              ...c,
              replies: [
                ...c.replies,
                {
                  id: uuid(),
                  author: "You",
                  text,
                  createdAt: new Date().toISOString(),
                },
              ],
            }
          : c,
      ),
    );
    setHasUnsaved(true);
  }, []);

  // ── Reset ──────────────────────────────────────────────────────────────
  const handleReset = useCallback(() => {
    if (!confirm("Reset editor to default content? All changes will be lost."))
      return;
    clearStorage();
    localStorage.removeItem("slate_editor_saved_at");
    setSavedAt("");
    setValue(DEFAULT_CONTENT);
    setComments([]);
    setActiveId(null);
    setEditPending(null);
    setPreviewBox(null);
    setHasUnsaved(false);
    setIsPreview(true);
    setShowComments(false);
    editor.children = DEFAULT_CONTENT;
    editor.history = { undos: [], redos: [] };
    Editor.normalize(editor, { force: true });
  }, [editor]);

  const renderElement = useCallback(
    (p: Parameters<typeof Element>[0]) => <Element {...p} />,
    [],
  );
  const renderLeaf = useCallback(
    (p: Parameters<typeof Leaf>[0]) => <Leaf {...p} />,
    [],
  );

  const savedLabel = savedAt
    ? new Date(savedAt).toLocaleString("en-US", {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      })
    : "";

  const activeCommentCount = comments.filter((c) => !c.resolved).length;

  // In preview mode: hide highlights when comments are off
  const editableClass = [
    "editable-area",
    isPreview ? "preview-selectable-content" : "",
    isPreview && !showComments ? "hide-highlights" : "",
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <div className="app-container">
      {/* ── Header ────────────────────────────────────────────────────── */}
      <header className="app-header">
        <div className="app-logo">
          <span className="logo-mark">✦</span>
          <span className="logo-text">
            Slate<em>Writer</em>
          </span>
        </div>

        {isPreview ? (
          <>
            {/* Preview mode badge */}
            <div className="preview-badge">
              <Eye size={13} /> Preview
            </div>
            {savedLabel && (
              <span className="app-tagline preview-saved-at">
                Saved {savedLabel}
              </span>
            )}

            <div className="header-spacer" />

            {/* Toggle comments button */}
            <button
              className={`btn-toggle-comments ${showComments ? "active" : ""}`}
              onClick={handleToggleComments}
              title={showComments ? "Hide comments" : "Show comments"}
            >
              {showComments ? (
                <>
                  <MessageSquareOff size={15} /> Hide Comments
                </>
              ) : (
                <>
                  <MessageSquare size={15} /> Show Comments
                  {activeCommentCount > 0 && (
                    <span className="btn-comments-badge">
                      {activeCommentCount}
                    </span>
                  )}
                </>
              )}
            </button>

            {/* Edit button */}
            <button
              className="btn-edit"
              onClick={() => {
                setIsPreview(false);
                setPreviewBox(null);
              }}
            >
              <Edit3 size={14} /> Edit
            </button>
          </>
        ) : (
          <>
            <div className="mode-tag">
              <Edit3 size={13} /> Edit Mode
            </div>
            {hasUnsaved && (
              <div className="unsaved-indicator">
                <span className="unsaved-dot-header" /> Unsaved changes
              </div>
            )}
            <div className="header-spacer" />
          </>
        )}
      </header>

      {/* ── Layout ────────────────────────────────────────────────────── */}
      <div className="main-layout">
        <Slate editor={editor} initialValue={value} onChange={handleChange}>
          {/* Editor column */}
          <div className="editor-column">
            {!isPreview && (
              <Toolbar
                onAddComment={handleEditAddComment}
                onReset={handleReset}
                onSave={handleSave}
                hasUnsavedChanges={hasUnsaved}
              />
            )}

            {/* Preview hint — only when comments panel is open */}
            {isPreview && showComments && (
              <div className="preview-banner">
                <MessageSquare size={13} />
                <span>
                  <strong>Select text</strong> to add a comment ·{" "}
                  <strong>Click highlighted text</strong> to jump to its comment
                </span>
              </div>
            )}

            <div className="editor-scroll-area" ref={scrollRef}>
              <div className="editor-page-wrapper">
                <div
                  className="editor-page"
                  ref={pageRef}
                  style={{ position: "relative" }}
                  onClick={
                    isPreview ? handlePreviewPageClick : handleEditPageClick
                  }
                  onMouseUp={isPreview ? handlePreviewMouseUp : undefined}
                >
                  <Editable
                    readOnly={isPreview}
                    renderElement={renderElement}
                    renderLeaf={renderLeaf}
                    onKeyDown={!isPreview ? handleKeyDown : undefined}
                    spellCheck={!isPreview}
                    autoFocus={!isPreview}
                    placeholder="Start writing…"
                    className={editableClass}
                  />

                  {/* Inline box — preview only, comments-open only */}
                  {isPreview && showComments && previewBox && (
                    <InlineCommentBox
                      state={previewBox}
                      onSubmit={handlePreviewCommentSubmit}
                      onCancel={handleCancelPreview}
                    />
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar — edit mode: always visible · preview mode: only when showComments */}
          {(!isPreview || showComments) && (
            <CommentsSidebar
              comments={comments}
              activeCommentId={activeId}
              onSelectComment={handleSelectComment}
              onResolve={handleResolve}
              onDelete={handleDelete}
              onAddReply={handleAddReply}
              editPending={editPending}
              onSubmitEditPending={handleEditCommentSubmit}
              onCancelEditPending={() => setEditPending(null)}
            />
          )}
        </Slate>
      </div>
    </div>
  );
};
