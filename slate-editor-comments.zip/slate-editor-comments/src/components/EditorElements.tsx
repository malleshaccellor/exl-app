import React from 'react';
import { RenderElementProps, RenderLeafProps } from 'slate-react';
import { CustomText } from '../types/editor';

export const Element: React.FC<RenderElementProps> = ({ attributes, children, element }) => {
  const el = element as typeof element & { align?: string; indent?: number };
  const style: React.CSSProperties = {
    textAlign: (el.align as React.CSSProperties['textAlign']) || 'left',
    paddingLeft: el.indent ? `${el.indent * 2}em` : undefined,
  };
  switch (element.type) {
    case 'heading-one':    return <h1 {...attributes} style={style} className="editor-h1">{children}</h1>;
    case 'heading-two':    return <h2 {...attributes} style={style} className="editor-h2">{children}</h2>;
    case 'heading-three':  return <h3 {...attributes} style={style} className="editor-h3">{children}</h3>;
    case 'blockquote':     return <blockquote {...attributes} className="editor-blockquote">{children}</blockquote>;
    case 'code':           return <pre {...attributes} className="editor-code"><code>{children}</code></pre>;
    case 'bulleted-list':  return <ul {...attributes} className="editor-ul">{children}</ul>;
    case 'numbered-list':  return <ol {...attributes} className="editor-ol">{children}</ol>;
    case 'list-item':      return <li {...attributes} style={style} className="editor-li">{children}</li>;
    case 'divider':
      return (
        <div {...attributes} contentEditable={false}>
          <hr className="editor-divider" />{children}
        </div>
      );
    default: return <p {...attributes} style={style} className="editor-p">{children}</p>;
  }
};

export const Leaf: React.FC<RenderLeafProps> = ({ attributes, children, leaf }) => {
  const l = leaf as CustomText;
  const style: React.CSSProperties = {
    fontSize:        l.fontSize   ? `${l.fontSize}px`           : undefined,
    fontFamily:      l.fontFamily || undefined,
    color:           l.color      || undefined,
    backgroundColor: l.highlight  ? 'rgba(255,212,0,0.35)'      : undefined,
  };

  let el = <span style={style}>{children}</span>;
  if (l.bold)          el = <strong>{el}</strong>;
  if (l.italic)        el = <em>{el}</em>;
  if (l.underline)     el = <u>{el}</u>;
  if (l.strikethrough) el = <s>{el}</s>;

  if (l.commentId) {
    el = (
      <span
        className="comment-highlight"
        data-comment-id={l.commentId}
      >
        {el}
      </span>
    );
  }

  return <span {...attributes}>{el}</span>;
};
