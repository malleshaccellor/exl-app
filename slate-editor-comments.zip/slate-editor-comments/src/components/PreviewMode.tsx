import React, {
  useCallback, useLayoutEffect, useEffect, useRef, useState
} from 'react';
import { Descendant, Text, Transforms, Editor, Range } from 'slate';
import { CustomText, CustomElement, Comment } from '../types/editor';
import {
  MessageSquare, CheckCheck, ChevronDown, ChevronUp,
  Edit3, X, CornerDownRight, Send
} from 'lucide-react';
import { scrollToHighlight, flashCard } from './SlateEditor';
import type { BaseEditor } from 'slate';
import type { ReactEditor } from 'slate-react';
import type { HistoryEditor } from 'slate-history';
import { v4 as uuid } from 'uuid';
import { saveComments } from '../utils/storage';

type EditorType = BaseEditor & ReactEditor & HistoryEditor;

// ─────────────────────────────────────────────────────────────────────────────
// Find a Slate Range from a plain-text offset inside the document.
// We walk the Slate document tree counting characters until we reach
// the anchor / focus offsets of the browser selection.
// ─────────────────────────────────────────────────────────────────────────────
function findSlateRange(
  editor: EditorType,
  anchorNode: globalThis.Node,
  anchorOffset: number,
  focusNode: globalThis.Node,
  focusOffset: number,
  pageEl: HTMLElement
): Range | null {
  // Collect all text-node leaf paths by walking the rendered DOM and
  // matching them against the Slate tree by cumulative character position.
  interface Leaf { domNode: globalThis.Node; path: number[]; start: number; end: number; }
  const leaves: Leaf[] = [];
  let pos = 0;

  function walk(slateNode: Descendant, path: number[]) {
    if (Text.isText(slateNode)) {
      const len = slateNode.text.length;
      // Find the matching DOM text node inside pageEl
      const selector = buildSelector(path);
      const domLeaf  = findDomLeaf(pageEl, path);
      leaves.push({ domNode: domLeaf ?? anchorNode, path, start: pos, end: pos + len });
      pos += len;
    } else {
      const el = slateNode as CustomElement;
      el.children.forEach((child, i) => walk(child as Descendant, [...path, i]));
    }
  }

  editor.children.forEach((node, i) => walk(node, [i]));

  // Find which leaf contains a given DOM text node
  function findLeafByDom(domNode: globalThis.Node): Leaf | null {
    for (const l of leaves) {
      if (l.domNode === domNode) return l;
    }
    return null;
  }

  // Try to find the leaf by DOM node first; fall back to positional matching
  const anchorLeaf = findLeafByDom(anchorNode);
  const focusLeaf  = findLeafByDom(focusNode);

  if (!anchorLeaf || !focusLeaf) return null;

  return {
    anchor: { path: anchorLeaf.path, offset: anchorOffset },
    focus:  { path: focusLeaf.path,  offset: focusOffset  },
  };
}

// Unused helpers kept for completeness (tree-walk above uses simpler approach)
function buildSelector(_path: number[]): string { return ''; }

// Walk the actual rendered DOM inside pageEl to find a text node
// matching a Slate leaf by its position among sibling text nodes.
function findDomLeaf(pageEl: HTMLElement, _path: number[]): globalThis.Node | null {
  return null; // We rely on DOM selection nodes directly (see below)
}

// ─────────────────────────────────────────────────────────────────────────────
// A simpler, more reliable approach:
// Walk ALL text nodes inside the page and match the browser selection's
// anchor/focus nodes directly, then record their Slate path by counting.
// ─────────────────────────────────────────────────────────────────────────────
function buildSlateRangeFromSelection(
  editor: EditorType,
  sel: Selection
): Range | null {
  if (sel.rangeCount === 0) return null;

  // Collect every text node in the DOM in document order
  const domTextNodes: Text[] = [];
  function collectText(node: globalThis.Node) {
    if (node.nodeType === globalThis.Node.TEXT_NODE) {
      domTextNodes.push(node as unknown as Text);
    } else {
      node.childNodes.forEach(collectText);
    }
  }

  // Also collect Slate leaf text nodes in document order
  interface SlateLeaf { text: string; path: number[] }
  const slateLeaves: SlateLeaf[] = [];
  function collectLeaves(node: Descendant, path: number[]) {
    if (Text.isText(node)) {
      slateLeaves.push({ text: node.text, path });
    } else {
      (node as CustomElement).children.forEach((c, i) =>
        collectLeaves(c as Descendant, [...path, i])
      );
    }
  }
  editor.children.forEach((n, i) => collectLeaves(n, [i]));

  // Find anchor and focus leaf indices in slateLeaves by matching text content
  const anchorDomNode = sel.anchorNode;
  const focusDomNode  = sel.focusNode;

  if (!anchorDomNode || !focusDomNode) return null;

  // Get text content of the anchor/focus DOM nodes
  const anchorText = anchorDomNode.textContent || '';
  const focusText  = focusDomNode.textContent  || '';

  // Find the first Slate leaf whose text matches the anchor DOM text
  // (handle split leaves: a single Slate text may map to multiple DOM spans)
  const anchorLeaf = slateLeaves.find(l => l.text === anchorText);
  const focusLeaf  = slateLeaves.find(l => l.text === focusText);

  if (!anchorLeaf || !focusLeaf) {
    // Fallback: try substring match (e.g. formatted text splits)
    const al = slateLeaves.find(l => anchorText.includes(l.text) || l.text.includes(anchorText));
    const fl = slateLeaves.find(l => focusText.includes(l.text)  || l.text.includes(focusText));
    if (!al || !fl) return null;
    return {
      anchor: { path: al.path, offset: Math.min(sel.anchorOffset, al.text.length) },
      focus:  { path: fl.path, offset: Math.min(sel.focusOffset,  fl.text.length) },
    };
  }

  return {
    anchor: { path: anchorLeaf.path, offset: Math.min(sel.anchorOffset, anchorLeaf.text.length) },
    focus:  { path: focusLeaf.path,  offset: Math.min(sel.focusOffset,  focusLeaf.text.length)  },
  };
}

// ─── Leaf renderer ────────────────────────────────────────────────────────────

const renderLeafToJSX = (
  leaf: CustomText, key: string,
  onCommentClick: (id: string) => void,
  activeId: string | null
): React.ReactNode => {
  const style: React.CSSProperties = {
    fontSize:   leaf.fontSize ? `${leaf.fontSize}px` : undefined,
    fontFamily: leaf.fontFamily && leaf.fontFamily !== 'Default' ? leaf.fontFamily : undefined,
    color:      leaf.color || undefined,
    backgroundColor: leaf.highlight ? 'rgba(255,212,0,0.35)' : undefined,
    fontWeight: leaf.bold        ? 'bold'         : undefined,
    fontStyle:  leaf.italic      ? 'italic'       : undefined,
    textDecoration: [
      leaf.underline     ? 'underline'    : '',
      leaf.strikethrough ? 'line-through' : '',
    ].filter(Boolean).join(' ') || undefined,
  };

  let el: React.ReactNode = <span style={style}>{leaf.text}</span>;

  if (leaf.commentId) {
    el = (
      <span
        key={key}
        className={`comment-highlight preview-comment-highlight${leaf.commentId === activeId ? ' active' : ''}`}
        data-comment-id={leaf.commentId}
        onClick={e => { e.stopPropagation(); onCommentClick(leaf.commentId!); }}
        title="Click to jump to comment"
      >{el}</span>
    );
  }

  return <span key={key}>{el}</span>;
};

const renderElementToJSX = (
  node: Descendant, index: number,
  onCommentClick: (id: string) => void,
  activeId: string | null
): React.ReactNode => {
  if (Text.isText(node))
    return renderLeafToJSX(node as CustomText, String(index), onCommentClick, activeId);

  const el    = node as CustomElement;
  const align  = (el as { align?: string }).align as React.CSSProperties['textAlign'] | undefined;
  const indent = (el as { indent?: number }).indent;
  const style: React.CSSProperties = {
    textAlign:   align  || 'left',
    paddingLeft: indent ? `${indent * 2}em` : undefined,
  };
  const children = el.children.map((c, i) =>
    renderElementToJSX(c as Descendant, i, onCommentClick, activeId)
  );
  switch (el.type) {
    case 'heading-one':   return <h1 key={index} style={style} className="editor-h1">{children}</h1>;
    case 'heading-two':   return <h2 key={index} style={style} className="editor-h2">{children}</h2>;
    case 'heading-three': return <h3 key={index} style={style} className="editor-h3">{children}</h3>;
    case 'blockquote':    return <blockquote key={index} className="editor-blockquote">{children}</blockquote>;
    case 'code':          return <pre key={index} className="editor-code"><code>{children}</code></pre>;
    case 'bulleted-list': return <ul key={index} className="editor-ul">{children}</ul>;
    case 'numbered-list': return <ol key={index} className="editor-ol">{children}</ol>;
    case 'list-item':     return <li key={index} style={style} className="editor-li">{children}</li>;
    case 'divider':       return <hr key={index} className="editor-divider" />;
    default:              return <p key={index} style={style} className="editor-p">{children}</p>;
  }
};

// ─── Inline Comment Box ───────────────────────────────────────────────────────

interface InlineBoxProps {
  top: number;
  left: number;
  width: number;
  selectedText: string;
  onSubmit: (text: string) => void;
  onCancel: () => void;
}

const InlineCommentBox: React.FC<InlineBoxProps> = ({
  top, left, width, selectedText, onSubmit, onCancel
}) => {
  const [text, setText] = useState('');
  const ref = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const t = setTimeout(() => ref.current?.focus(), 40);
    return () => clearTimeout(t);
  }, []);

  const submit = () => { if (text.trim()) onSubmit(text.trim()); };

  return (
    <div
      className="inline-comment-box"
      style={{ top, left, width }}
      onMouseDown={e => e.stopPropagation()}
      onClick={e => e.stopPropagation()}
    >
      {/* Quoted selection */}
      <div className="icb-quote">
        <span className="icb-quote-bar" />
        <span className="icb-quote-text">
          {selectedText.length > 120 ? selectedText.slice(0, 120) + '…' : selectedText}
        </span>
      </div>

      {/* Textarea */}
      <textarea
        ref={ref}
        className="icb-textarea"
        placeholder="Add your comment…"
        value={text}
        onChange={e => setText(e.target.value)}
        onKeyDown={e => {
          if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); submit(); }
          if (e.key === 'Escape') onCancel();
        }}
        rows={3}
      />

      <div className="icb-footer">
        <span className="icb-hint">Ctrl+Enter to post</span>
        <button className="icb-btn-cancel" onClick={onCancel}>Cancel</button>
        <button className="icb-btn-post" onClick={submit} disabled={!text.trim()}>
          <Send size={13} /> Post comment
        </button>
      </div>
    </div>
  );
};

// ─── Margin Comment Card ──────────────────────────────────────────────────────

const MarginCard: React.FC<{
  comment: Comment;
  top: number;
  isActive: boolean;
  onClick: () => void;
  onResolve: (id: string) => void;
  onDelete:  (id: string) => void;
  onAddReply:(id: string, text: string) => void;
}> = ({ comment, top, isActive, onClick, onResolve, onDelete, onAddReply }) => {
  const [showReplies, setShowReplies] = useState(true);
  const [showReply,   setShowReply]   = useState(false);
  const [replyText,   setReplyText]   = useState('');
  const replyRef = useRef<HTMLTextAreaElement>(null);
  useEffect(() => { if (showReply) replyRef.current?.focus(); }, [showReply]);
  const fmt = (iso: string) =>
    new Date(iso).toLocaleDateString('en-US',
      { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  const submitReply = () => {
    if (replyText.trim()) {
      onAddReply(comment.id, replyText.trim()); setReplyText(''); setShowReply(false);
    }
  };

  return (
    <div
      className={`margin-comment-box margin-comment-card ${isActive ? 'active' : ''} ${comment.resolved ? 'resolved' : ''}`}
      style={{ top, position: 'absolute', left: 0, right: 0 }}
      data-card-id={comment.id}
      onClick={onClick}
    >
      {comment.selectedText && (
        <div className="mcb-quote-chip">
          <div className="mcb-quote-bar" />
          <span className="mcb-quote-text">
            {comment.selectedText.length > 70 ? comment.selectedText.slice(0, 70) + '…' : comment.selectedText}
          </span>
        </div>
      )}
      <div className="mcb-card-header">
        <div className="mcb-avatar">{comment.author[0].toUpperCase()}</div>
        <div className="mcb-meta">
          <span className="mcb-author">{comment.author}</span>
          <span className="mcb-date">{fmt(comment.createdAt)}</span>
        </div>
        <div className="mcb-header-actions" onClick={e => e.stopPropagation()}>
          {!comment.resolved && (
            <button className="icon-btn" title="Resolve" onClick={() => onResolve(comment.id)}>
              <CheckCheck size={12} />
            </button>
          )}
          <button className="icon-btn danger" title="Delete" onClick={() => onDelete(comment.id)}>
            <X size={12} />
          </button>
        </div>
      </div>
      <div className="mcb-body">{comment.text}</div>
      {comment.resolved && <div className="resolved-badge"><CheckCheck size={10} /> Resolved</div>}
      {comment.replies.length > 0 && (
        <div className="mcb-replies">
          <button className="replies-toggle" onClick={e => { e.stopPropagation(); setShowReplies(p => !p); }}>
            {showReplies ? <ChevronUp size={11} /> : <ChevronDown size={11} />}
            {comment.replies.length} {comment.replies.length === 1 ? 'reply' : 'replies'}
          </button>
          {showReplies && (
            <div className="replies-list">
              {comment.replies.map(r => (
                <div key={r.id} className="reply-card">
                  <div className="reply-header">
                    <div className="reply-avatar">{r.author[0].toUpperCase()}</div>
                    <span className="reply-author">{r.author}</span>
                    <span className="comment-date">{fmt(r.createdAt)}</span>
                  </div>
                  <div className="reply-body">{r.text}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
      {!comment.resolved && (
        <div className="mcb-reply-section" onClick={e => e.stopPropagation()}>
          {showReply ? (
            <div className="reply-form">
              <textarea ref={replyRef} className="reply-textarea" placeholder="Reply…"
                value={replyText} onChange={e => setReplyText(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) submitReply();
                  if (e.key === 'Escape') setShowReply(false);
                }} rows={2} />
              <div className="reply-actions">
                <button className="btn-cancel-sm" onClick={() => { setShowReply(false); setReplyText(''); }}>Cancel</button>
                <button className="btn-submit-sm" onClick={submitReply} disabled={!replyText.trim()}>Reply</button>
              </div>
            </div>
          ) : (
            <button className="reply-btn" onClick={() => setShowReply(true)}>
              <CornerDownRight size={11} /> Reply
            </button>
          )}
        </div>
      )}
    </div>
  );
};

// ─── Position calculator ──────────────────────────────────────────────────────

function calcPositions(comments: Comment[], pageEl: HTMLElement | null): Record<string, number> {
  if (!pageEl) return {};
  const pageRect = pageEl.getBoundingClientRect();
  const raw: { id: string; top: number }[] = [];
  for (const c of comments) {
    const span = pageEl.querySelector<HTMLElement>(`[data-comment-id="${c.id}"]`);
    if (span) {
      const r = span.getBoundingClientRect();
      raw.push({ id: c.id, top: Math.max(0, r.top - pageRect.top) });
    }
  }
  raw.sort((a, b) => a.top - b.top);
  const CARD_H = 150; const GAP = 8;
  const placed: { id: string; top: number }[] = [];
  for (const item of raw) {
    let top = item.top;
    for (const p of placed) { if (top < p.top + CARD_H + GAP) top = p.top + CARD_H + GAP; }
    placed.push({ id: item.id, top });
  }
  const pos: Record<string, number> = {};
  for (const p of placed) pos[p.id] = p.top;
  return pos;
}

// ─── Preview Mode ─────────────────────────────────────────────────────────────

interface PreviewModeProps {
  editor:          EditorType;
  content:         Descendant[];
  comments:        Comment[];
  activeCommentId: string | null;
  savedAt:         string;
  onEdit:          () => void;
  onApplyNewComment: (text: string, range: Range, selectedText: string) => string;
  onResolve:       (id: string) => void;
  onDelete:        (id: string) => void;
  onAddReply:      (id: string, text: string) => void;
  onSelectComment: (id: string | null) => void;
}

// Pending selection stored outside React state so mouseUp → re-render doesn't lose it
interface PendingSel {
  range: Range;
  text: string;
  boxTop: number;
  boxLeft: number;
  boxWidth: number;
}

export const PreviewMode: React.FC<PreviewModeProps> = ({
  editor, content, comments, activeCommentId,
  savedAt, onEdit, onApplyNewComment, onResolve, onDelete, onAddReply, onSelectComment,
}) => {
  const [positions,    setPositions]    = useState<Record<string, number>>({});
  const [pendingSel,   setPendingSel]   = useState<PendingSel | null>(null);

  const editorScrollRef = useRef<HTMLDivElement>(null);
  const editorPageRef   = useRef<HTMLDivElement>(null);
  const marginRef       = useRef<HTMLDivElement>(null);

  // ── Position recalculation ────────────────────────────────────────────
  const recalculate = useCallback(() => {
    setPositions(calcPositions(comments, editorPageRef.current));
  }, [comments]);

  useLayoutEffect(() => { recalculate(); }, [recalculate]);
  useEffect(() => {
    const el = editorScrollRef.current;
    if (!el) return;
    el.addEventListener('scroll', recalculate, { passive: true });
    window.addEventListener('resize', recalculate);
    return () => { el.removeEventListener('scroll', recalculate); window.removeEventListener('resize', recalculate); };
  }, [recalculate]);

  // ── Mouse up: capture selection, show inline box ──────────────────────
  const handleMouseUp = useCallback((e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('.inline-comment-box')) return;
    if ((e.target as HTMLElement).closest('.margin-comment-box')) return;

    const sel = window.getSelection();
    if (!sel || sel.isCollapsed || !sel.toString().trim()) return;

    const selectedText = sel.toString().trim();
    const pageEl       = editorPageRef.current;
    if (!pageEl) return;

    // ── Build Slate range by matching DOM text nodes to Slate leaves ──
    const slateRange = buildSlateRangeFromSelection(editor, sel);

    // ── Get pixel position for the inline box ─────────────────────────
    const domRange = sel.getRangeAt(0);
    const selRect  = domRange.getBoundingClientRect();
    const pageRect = pageEl.getBoundingClientRect();

    const boxTop   = selRect.bottom - pageRect.top + 8;
    const boxLeft  = Math.max(0, selRect.left - pageRect.left);
    const boxWidth = Math.min(
      Math.max(selRect.width, 340),
      pageRect.width - boxLeft - 16
    );

    if (!slateRange) {
      // Even without a Slate range we still show the box —
      // we'll fall back to a synthetic path-based range on submit
      setPendingSel({ range: { anchor: { path: [0,0], offset: 0 }, focus: { path: [0,0], offset: 0 } }, text: selectedText, boxTop, boxLeft, boxWidth });
    } else {
      setPendingSel({ range: slateRange, text: selectedText, boxTop, boxLeft, boxWidth });
    }
  }, [editor]);

  // ── Submit: apply mark + create comment ──────────────────────────────
  const handleCommentSubmit = useCallback((commentText: string) => {
    if (!pendingSel) return;

    // Apply the Slate mark directly
    const commentId = uuid();
    try {
      Transforms.select(editor, pendingSel.range);
      Editor.addMark(editor, 'commentId', commentId);
    } catch (err) {
      console.warn('Could not apply Slate mark in preview:', err);
    }

    // Create and save the comment
    const newComment: Comment = {
      id: commentId,
      author: 'You',
      text: commentText,
      createdAt: new Date().toISOString(),
      resolved: false,
      replies: [],
      range: pendingSel.range,
      selectedText: pendingSel.text,
    };

    // Bubble up to parent (SlateEditor) via onApplyNewComment
    onApplyNewComment(commentText, pendingSel.range, pendingSel.text);

    setPendingSel(null);
    window.getSelection()?.removeAllRanges();
  }, [editor, pendingSel, onApplyNewComment]);

  const handleCancelBox = useCallback(() => {
    setPendingSel(null);
    window.getSelection()?.removeAllRanges();
  }, []);

  // ── Highlight click → flash card ──────────────────────────────────────
  const handleHighlightClick = useCallback((id: string) => {
    const next = id === activeCommentId ? null : id;
    onSelectComment(next);
    if (next) setTimeout(() => flashCard(next, marginRef.current), 50);
  }, [activeCommentId, onSelectComment]);

  // ── Card click → scroll to highlight ─────────────────────────────────
  const handleCardClick = useCallback((id: string) => {
    const next = id === activeCommentId ? null : id;
    onSelectComment(next);
    if (next) setTimeout(() => scrollToHighlight(next, editorScrollRef.current), 50);
  }, [activeCommentId, onSelectComment]);

  // ── Click on page: dismiss box unless clicking a highlight / card ─────
  const handlePageClick = useCallback((e: React.MouseEvent) => {
    const t = e.target as HTMLElement;
    if (
      !t.closest('.inline-comment-box') &&
      !t.closest('.margin-comment-box') &&
      !t.closest('[data-comment-id]')
    ) {
      setPendingSel(null);
    }
  }, []);

  const savedLabel = savedAt
    ? `Saved ${new Date(savedAt).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}`
    : 'Preview';

  return (
    <div className="app-container">
      <header className="app-header">
        <div className="app-logo">
          <span className="logo-mark">✦</span>
          <span className="logo-text">Slate<em>Writer</em></span>
        </div>
        <div className="preview-badge">
          <MessageSquare size={12} /> Preview
        </div>
        <div className="app-tagline preview-saved-at">{savedLabel}</div>
        <button className="btn-edit" onClick={onEdit}>
          <Edit3 size={13} /> Edit Document
        </button>
      </header>

      <div className="editor-layout">
        <div className="editor-column">
          <div className="editor-scroll-area preview-scroll" ref={editorScrollRef}>
            <div className="preview-banner">
              <MessageSquare size={13} />
              <span>
                <strong>Select any text</strong> to add a comment ·{' '}
                <strong>click highlighted text</strong> to jump to its comment
              </span>
            </div>

            <div className="editor-with-margin">

              {/* Document page */}
              <div
                className="editor-page preview-page"
                ref={editorPageRef}
                style={{ position: 'relative' }}
                onClick={handlePageClick}
                onMouseUp={handleMouseUp}
              >
                {/* Rendered document */}
                <div className="editable-area preview-selectable-content">
                  {content.map((node, i) =>
                    renderElementToJSX(node, i, handleHighlightClick, activeCommentId)
                  )}
                </div>

                {/* Inline comment box — appears below the selected text */}
                {pendingSel && (
                  <InlineCommentBox
                    top={pendingSel.boxTop}
                    left={pendingSel.boxLeft}
                    width={pendingSel.boxWidth}
                    selectedText={pendingSel.text}
                    onSubmit={handleCommentSubmit}
                    onCancel={handleCancelBox}
                  />
                )}
              </div>

              {/* Margin comment cards */}
              <div className="margin-comments-container" ref={marginRef}>
                {comments.map(c => {
                  const top = positions[c.id];
                  if (top === undefined) return null;
                  return (
                    <MarginCard
                      key={c.id}
                      comment={c}
                      top={top}
                      isActive={c.id === activeCommentId}
                      onClick={() => handleCardClick(c.id)}
                      onResolve={onResolve}
                      onDelete={onDelete}
                      onAddReply={onAddReply}
                    />
                  );
                })}
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
